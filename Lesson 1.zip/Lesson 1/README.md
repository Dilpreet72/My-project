# JS Shopping cart
A simple shopping cart created with pure Javascript, Html and CSS. The items can be saved in the shopping cart thanks to the property of Local Storage.

![Image design](/img/project-cart-design.jpg)

Project from Udemy course [JavaScript Moderno](https://www.udemy.com/javascript-moderno-guia-definitiva-construye-10-proyectos)

Technologies used:

- HTML5

- CSS3

- JavaScript
